Created by Mestik78
https://github.com/Mestik78

How to use:

1- Place your images inside the folder rawimages
2- Place the texts you want it to use in the words.txt file (each line is used in a different image)
3- Run cmd
4- Go to this folder with cmd
5- Run "python topng.py" in cmd
6- When it's done run "python shitpostCreator.py" in cmd
7- Write the number of images that you want to create as a number
8- Press enter
9- Your images are inside the exports folder